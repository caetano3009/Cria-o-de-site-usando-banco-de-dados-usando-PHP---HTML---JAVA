<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Vagas Cadastradas</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <div class="header-content-wrapper">
            <h1><i class="fas fa-bullhorn"></i> Minhas Vagas Cadastradas</h1>
            <div class="perfil-usuario-area">
                 <a href="index.php" class="btn-admin"><i class="fas fa-home"></i> Início</a>
            </div>
        </div>
        <nav></nav>
    </header>
    <main>
        <h2>Página de Vagas Cadastradas</h2>
        <p>Em desenvolvimento...</p>
    </main>
</body>
</html>